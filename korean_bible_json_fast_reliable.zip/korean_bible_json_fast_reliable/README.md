# 한국어 성경 JSON 파일 세트

업로드된 PDF에서 추출해 **66권 제목별 JSON**으로 나눈 GitHub Pages용 정적 파일입니다.

## 핵심 구조
- `data/books.json` : 66권 목록
- `data/books/*.json` : 책별 메타데이터
- `data/chunks/{book}/{n}.json` : 책 본문을 작은 조각으로 분리한 JSON
- `data/index/chunks.min.json` : 검색용 인덱스. 검색할 때만 로딩
- `index.html`, `app.js`, `style.css` : 바로 실행 가능한 무료 성경 웹앱

## 왜 빠른가?
성경 전체를 처음부터 받지 않고, 사용자가 선택한 책의 작은 조각 하나만 불러옵니다. 그래서 GitHub Pages에서도 초기 로딩이 가볍습니다.

## 0원 배포 방법
1. 이 폴더 안의 파일 전체를 GitHub 저장소에 업로드
2. GitHub 저장소 → Settings → Pages
3. Deploy from branch → main / root 선택
4. 배포 주소 접속

## 1억 명 동시접속 관련 현실 체크
이 구조는 트래픽 최소화 구조입니다. 다만 GitHub Pages 무료 서비스 자체가 1억 동시접속을 보장하는 것은 아닙니다. 실제 초대형 트래픽은 Cloudflare Pages 같은 CDN 캐시를 앞에 두는 것이 안전합니다.
